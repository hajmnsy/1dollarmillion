=== FINAL FIX - ALL FILES ===

These files fix the "BigInt(NaN)" crash permanently.

Each file has TWO copies:
1. Files starting with "src_" → go to the src/ folder
2. Files starting with "root_" → go to the root folder

Example:
- src_hooks_useLottery.ts → replace src/hooks/useLottery.ts
- root_hooks_useLottery.ts → replace hooks/useLottery.ts

ALL files must be uploaded to BOTH locations.

=== FILES TO UPLOAD (16 files × 2 = 32 total) ===

src/hooks/useLottery.ts          ← src_hooks_useLottery.ts
hooks/useLottery.ts              ← root_hooks_useLottery.ts

src/hooks/useDeposit.ts          ← src_hooks_useDeposit.ts
hooks/useDeposit.ts              ← root_hooks_useDeposit.ts

src/hooks/useActivityFeed.ts     ← src_hooks_useActivityFeed.ts
hooks/useActivityFeed.ts         ← root_hooks_useActivityFeed.ts

src/lib/contract/config.ts       ← src_lib_contract_config.ts
lib/contract/config.ts           ← root_lib_contract_config.ts

src/app/[locale]/dashboard/page.tsx  ← src_app_locale_dashboard_page.tsx
app/[locale]/dashboard/page.tsx      ← root_app_locale_dashboard_page.tsx

src/components/landing/Hero.tsx  ← src_components_landing_Hero.tsx
landing/Hero.tsx                 ← root_landing_Hero.tsx

src/components/landing/TransparencySection.tsx  ← src_components_landing_TransparencySection.tsx
landing/TransparencySection.tsx                 ← root_landing_TransparencySection.tsx

src/components/landing/SiteFooter.tsx  ← src_components_landing_SiteFooter.tsx
landing/SiteFooter.tsx                 ← root_landing_SiteFooter.tsx

src/components/dashboard/SolvencyCard.tsx       ← src_components_dashboard_SolvencyCard.tsx
dashboard/SolvencyCard.tsx                     ← root_dashboard_SolvencyCard.tsx

src/components/dashboard/PositionCard.tsx       ← src_components_dashboard_PositionCard.tsx
dashboard/PositionCard.tsx                     ← root_dashboard_PositionCard.tsx

src/components/dashboard/CompactReferralCard.tsx ← src_components_dashboard_CompactReferralCard.tsx
dashboard/CompactReferralCard.tsx               ← root_dashboard_CompactReferralCard.tsx

src/components/dashboard/PoolProgressCard.tsx   ← src_components_dashboard_PoolProgressCard.tsx
dashboard/PoolProgressCard.tsx                 ← root_dashboard_PoolProgressCard.tsx

src/components/dashboard/OddsCard.tsx           ← src_components_dashboard_OddsCard.tsx
dashboard/OddsCard.tsx                         ← root_dashboard_OddsCard.tsx

src/components/dashboard/DepositModal.tsx       ← src_components_dashboard_DepositModal.tsx
dashboard/DepositModal.tsx                     ← root_dashboard_DepositModal.tsx

src/components/dashboard/WithdrawModal.tsx      ← src_components_dashboard_WithdrawModal.tsx
dashboard/WithdrawModal.tsx                    ← root_dashboard_WithdrawModal.tsx

src/components/web3/WalletButton.tsx            ← src_components_web3_WalletButton.tsx
web3/WalletButton.tsx                          ← root_web3_WalletButton.tsx
